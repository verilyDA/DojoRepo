from django.shortcuts import render, HttpResponse, redirect
  # the index function is called when root is visited
def index(request):
    response = "Placeholder to later display all blogs"
    return HttpResponse(response)

def new(request):
    response = 'placeholder to display a new form to create a blog'
    return HttpResponse(response)

def create(request):
    return HttpResponse('create placeholder')

def number(request):
    return HttpResponse('blog number page')

def numEdit(request):
    return HttpResponse('blog edit page')

def numDel(request):
    return HttpResponse('blog delete page')
    
