from django.apps import AppConfig


class SurveyformConfig(AppConfig):
    name = 'surveyForm'
