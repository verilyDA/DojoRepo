from django.apps import AppConfig


class DojogoldConfig(AppConfig):
    name = 'dojoGold'
