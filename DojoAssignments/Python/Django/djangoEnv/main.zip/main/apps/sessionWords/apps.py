from django.apps import AppConfig


class SessionwordsConfig(AppConfig):
    name = 'sessionWords'
