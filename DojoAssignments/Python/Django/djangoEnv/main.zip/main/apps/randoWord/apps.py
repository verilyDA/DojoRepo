from django.apps import AppConfig


class RandowordConfig(AppConfig):
    name = 'randoWord'
